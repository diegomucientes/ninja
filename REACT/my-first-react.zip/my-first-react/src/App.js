import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1 className ="try1">
          HELLO DOJO!
        </h1>
        <h2>
          Things i need to do:
          <ul>
            <li>Learn React</li> 
            <li>Climb Mt Everest</li> 
            <li>Run a Marathon</li> 
            <li>Feed the Dogs</li> 
          </ul>
        </h2>

     
      </header>
    </div>
  );
}

export default App;
